var fs=require('fs');
var request=require('request');
var chalk=require('chalk');
var trial=0;
var trial_limit=25;
function getZippedSub(t,file_url,location,callback){

      var r=request({url: file_url, encoding: null,timeout:6000,maxSockets:100,headers: {'User-Agent': 'Mozilla/5.0','Cookie':'LanguageFilter=13'}

  }, function(err, response, body) {
        if(!err && response.statusCode === 200){
          var output=response.rawHeaders[19].split('=')[1];
        fs.writeFile(location+output, body, function(err) {
          //console.log("file written!");
          callback(false,location+""+output,response);
        });

      }





      else{
        //console.log("error");

        if(trial===trial_limit){
        callback(true);
        return;
      }
      trial=trial+1;
      setTimeout(function () {


      getZippedSub("",file_url,location,callback);
      return;
    }, 2000);

      }

    });

  }


    module.exports=getZippedSub;
